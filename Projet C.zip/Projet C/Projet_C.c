#include <stdio.h>
#include <stdlib.h>

// LES STRUCTURES
typedef struct
{
    int x; //coordonnee horizontale
    int y; //coordonnee verticale
} Coord ;

typedef struct
{
    Coord c;
    int nimber;
} Case ;

//LES VARIABLES
int R, M, N, Next, Niveau, NbVoisines;
Case Pions [30]; //tableau des cases ou les pions se situent
Case Voisines [4]; //tableau des cases voisines

//LES PROTOTYPES DES FONCTIONS
int Lire_Entier(int, int);
void Lire_Parametres();
int Nimber(Case);
void Init_Grille();
int Contient_Pion(int, int);
void Affiche_Grille();
void Tab_Voisines(Case);
void Maj_Grille(int, int);
void Move_Joueur();
int Hasard(int, int);
void Move_Hasard();
int Nim_Addition();
void Move_Gagnant();

//LE MAIN
int main ()
{
    int alea; //entier aleatoire
    Lire_Parametres ();
    Init_Grille ();
    printf ("\n\nC'est parti !\n-------------\n\n");
    while (R)
    {
        Affiche_Grille();
        if (Next==1) //l'ordinateur joue
        {
            alea=Hasard(0,99); // tirage de pourcentage aleatoire
            printf("\nL'ordinateur joue : ");
            if (Niveau==1) //Niveau 1
            {
                if (alea<10) Move_Gagnant ();
                else Move_Hasard();
            }
            else if (Niveau==2) //Niveau 2
            {
                if (alea<50) Move_Gagnant ();
                else Move_Hasard();
            }
            else //Niveau 3
            {
                if (alea<90) Move_Gagnant ();
                else Move_Hasard();
            }
            Next=2;
        }
        else //le joueur joue
        {
            Move_Joueur();
            Next=1;
        }
    }
    if (Next==2) printf("\nC'est termine. Tu as perdu !\n");
    else printf("\nBravo, tu as gagne !\n");
    return 0;
}

// LES FONCTIONS

int Lire_Entier (int ent1, int ent2)
{
    int e, test, vide;
    do
    {
        test = scanf("%d", &e);
        while((vide=getchar())!='\n' && (vide!=EOF));
        if (test==0 || e<ent1 || e>ent2)
          printf("Erreur ! Saisir un nouvel entier.\n");
    }
    while(e<ent1 || e>ent2 || test!=1);
    return e;
}

void Lire_Parametres ()
{
    printf("Parametres du jeu\n-----------------\nNombres de lignes   : ");
    N=Lire_Entier(3,30);
    printf("Nombres de colonnes : ");
    M=Lire_Entier(3,30);
    printf("Nombres de pions    : ");
    R=Lire_Entier(1,N);
    printf("Niveau de 1 a 3     : ");
    Niveau=Lire_Entier(1,3);
    printf("Qui commence ? \nL'ordinateur (1) ou le joueur (2) : ");
    Next=Lire_Entier(1,2);
}

int Nimber(Case kase)
{
    int resultat=0;
    resultat = ((N-kase.c.x)%3^(M-kase.c.y)%3); //repetition d'une grille de 3x3
    return resultat;
}

void Init_Grille ()
{
    int i;
    for(i=0;i<R;i++) //mets R pions dans la colonne 1
    {
        Pions[i].c.x=1;
        Pions[i].c.y=i+1;
        Pions[i].nimber=Nimber(Pions[i]);
    }
}

int Contient_Pion (int x1, int y1)
{
    int i, trouve=0;
    for(i=0;i<R;i++)
    {
      if ((Pions[i].c.x==x1) && (Pions[i].c.y==y1)) trouve=1; //cherche avec  les coordonnees x1 et y1 si ils sont dans le tableau Pions
    }
    return trouve;
}

void Affiche_Grille ()
{
    int i,j;
    printf("   |");
    for(i=1;i<=M;i++)
    {
        printf("%2d |",i); //les colonnes
    }
    printf("\n");

    for(j=1;j<=N;j++)
    {
        printf("%3d|",j);// les lignes
        for(i=1;i<=M;i++)
        {
            if(Contient_Pion(i,j)) printf(" 0 |"); //pion
            else printf(" - |");//case sans pion
        }
        printf("\n");
    }
}

void Tab_Voisines (Case pion)
{
    NbVoisines=0;

    if (pion.c.x+1<=M) //voisin de droite +1
    {
        Voisines[NbVoisines].c.x=pion.c.x+1;
        Voisines[NbVoisines].c.y=pion.c.y;
        Voisines[NbVoisines].nimber=Nimber(Voisines[NbVoisines]);
        NbVoisines++;
    }
    if (pion.c.x+2<=M) //voisin de droite +2
    {
        Voisines[NbVoisines].c.x=pion.c.x+2;
        Voisines[NbVoisines].c.y=pion.c.y;
        Voisines[NbVoisines].nimber=Nimber(Voisines[NbVoisines]);
        NbVoisines++;
    }
    if (pion.c.y+1<=N)//voisin du bas +1
    {
        Voisines[NbVoisines].c.x=pion.c.x;
        Voisines[NbVoisines].c.y=pion.c.y+1;
        Voisines[NbVoisines].nimber=Nimber(Voisines[NbVoisines]);
        NbVoisines++;
    }
    if (pion.c.y+2<=N)//voisin du bas +2
    {
        Voisines[NbVoisines].c.x=pion.c.x;
        Voisines[NbVoisines].c.y=pion.c.y+2;
        Voisines[NbVoisines].nimber=Nimber(Voisines[NbVoisines]);
        NbVoisines++;
    }
}

void Maj_Grille (int p, int dest)//p est le numero du pion choisi et dest est la destination choisie
{
    int i;
    if ((Voisines[dest].c.x==M) && (Voisines[dest].c.y==N))//le pion tombe dans le puit
    {
        R--;
        for(i=p;i<R;i++) //sert a mettre a jour la table Pions
        {
            Pions[i].c.x=Pions[i+1].c.x;
            Pions[i].c.y=Pions[i+1].c.y;
            Pions[i].nimber=Pions[i+1].nimber;
        }
    }
    else // sinon le pion prend les coordonnees de destination (donc de la case voisine choisie)
    {
        Pions[p].c.x = Voisines[dest].c.x;
        Pions[p].c.y = Voisines[dest].c.y;
        Pions[p].nimber = Voisines[dest].nimber;
   }
}

void Move_Joueur()
{
    int i, choix=-1, dest=-1;
    printf ("\nA toi de jouer!\nChoisir un pion");
    for(i=0;i<R;i++) //choix du pion a deplacer
    {
        printf (" %d:(%d,%d)",i+1,Pions[i].c.x,Pions[i].c.y);
    }
    while (choix==-1) //saisie du choix
    {
        printf ("\n---> ");
        choix=Lire_Entier(1,R)-1;
    }

    printf ("Choisir la destination");
    Tab_Voisines (Pions[choix]);
    for(i=0;i<NbVoisines;i++)//choix du deplacement du pion
    {
        printf (" %d:(%d,%d)",i+1,Voisines[i].c.x,Voisines[i].c.y);
    }
    while (dest==-1) //saisie du choix de destination
    {
        printf ("\n---> ");
        dest=Lire_Entier(1,NbVoisines)-1;
    }

    Maj_Grille (choix, dest); //mise a jour de la grille
}

int Hasard(int min,int max)
{
   return rand()%max+min; //nombre aleatoire entre le parametre minimum et le parametre maximum
}

void Move_Hasard ()
{
    int choix, dest;
    choix=Hasard(1,R)-1; //l'ordinateur choisit un pion aleatoirement
    Tab_Voisines (Pions[choix]);
    dest=Hasard(1,NbVoisines)-1; //l'ordinateur choisit une destination aleatoirement
    printf("(%d,%d) ---> (%d,%d)\n\n", Pions[choix].c.x,Pions[choix].c.y, Voisines[dest].c.x, Voisines[dest].c.y); //montre le d�placement
    Maj_Grille (choix, dest);
}

int Nim_Addition()
{
    int resultat=0, i;

    for (i=0;i<R;i++)
    {
        resultat = resultat^Pions[i].nimber;//additionne tous les nimbers et les mets dans resultat
    }
    return resultat;
}

void Move_Gagnant()
{
    int nim, i, j, cherche=1;

    nim=Nim_Addition();
    if (nim==0) // si la nim-addition est nulle, l'ordinateur joue au hasard
    {
           Move_Hasard();
    }
    else // si la nim-addition n'est pas nulle, l'ordinateur joue un coup gagnant
    {
        i=0;
        while (i<R && cherche)//cherche le pion a deplacer
        {
            Tab_Voisines (Pions[i]);
            j=0;
            while (j<NbVoisines && cherche)
            {
                if (Voisines[j].nimber==0)//si la case voisine j possede un nimber de 0
                {
                    printf("(%d,%d) ---> (%d,%d)\n\n", Pions[i].c.x,Pions[i].c.y, Voisines[j].c.x, Voisines[j].c.y);//montre le d�placement au joueur
                    Maj_Grille (i, j); //mise a jour de la grille avec le pion i en destination de j
                    cherche=0;
                }
                j++;
            }
            i++;
        }
        if (cherche) Move_Hasard();
    }
 }
